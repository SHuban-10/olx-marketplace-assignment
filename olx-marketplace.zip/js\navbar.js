/**
 * OLX Marketplace - Global Navigation & Header/Footer Renderer
 * Injects consistent OLX-style branding, city filter selector, search bar, and auth status
 */

const Navbar = {
    render() {
        const headerEl = document.getElementById("main-header");
        const footerEl = document.getElementById("main-footer");

        if (headerEl) {
            headerEl.innerHTML = this.getHeaderHtml();
            this.bindHeaderEvents();
        }

        if (footerEl) {
            footerEl.innerHTML = this.getFooterHtml();
        }
    },

    getHeaderHtml() {
        const currentUser = Auth.getCurrentUser();
        const currentUrl = window.location.pathname;

        return `
            <!-- Top Alert Bar -->
            <div class="top-announcement">
                <span>✨ Web Developer Internship Assessment Project — OLX Marketplace Clone</span>
            </div>

            <!-- Main Navbar -->
            <nav class="navbar">
                <div class="container nav-content">
                    <!-- Brand Logo -->
                    <a href="index.html" class="brand-logo" title="OLX Marketplace Home">
                        <span class="logo-box">OLX</span>
                        <span class="logo-text">MARKET</span>
                    </a>

                    <!-- City Selector dropdown in Header -->
                    <div class="location-select-wrapper">
                        <span class="location-pin">📍</span>
                        <select id="header-city-select" class="nav-select">
                            <option value="">All India</option>
                            <option value="Mumbai">Mumbai</option>
                            <option value="Delhi">Delhi</option>
                            <option value="Bengaluru">Bengaluru</option>
                            <option value="Hyderabad">Hyderabad</option>
                            <option value="Pune">Pune</option>
                            <option value="Chennai">Chennai</option>
                            <option value="Kolkata">Kolkata</option>
                        </select>
                    </div>

                    <!-- Global Search Box -->
                    <form id="header-search-form" class="nav-search-form">
                        <input 
                            type="text" 
                            id="header-search-input" 
                            class="nav-search-input" 
                            placeholder="Find Cars, Mobile Phones, Services and more..."
                            autocomplete="off"
                        />
                        <button type="submit" class="nav-search-btn" title="Search">
                            🔍
                        </button>
                    </form>

                    <!-- Navigation Links & Pages required by assignment -->
                    <div class="nav-links">
                        <a href="category.html" class="nav-link ${currentUrl.includes('category.html') ? 'active' : ''}">Categories</a>
                        <a href="city.html" class="nav-link ${currentUrl.includes('city.html') ? 'active' : ''}">City Wise</a>
                        <a href="explore.html" class="nav-link ${currentUrl.includes('explore.html') ? 'active' : ''}">City + Category</a>
                    </div>

                    <!-- Auth & Post Ad Actions -->
                    <div class="nav-actions">
                        ${currentUser ? `
                            <div class="user-menu-dropdown">
                                <button class="user-btn" id="user-menu-btn">
                                    <span class="user-avatar">${currentUser.name.charAt(0).toUpperCase()}</span>
                                    <span class="user-name">${currentUser.name.split(' ')[0]}</span>
                                    <span class="dropdown-arrow">▾</span>
                                </button>
                                <div class="user-dropdown-content" id="user-dropdown-menu">
                                    <div class="dropdown-header">
                                        <strong>${currentUser.name}</strong>
                                        <small>${currentUser.email}</small>
                                    </div>
                                    <a href="my-listings.html">📦 My Listings</a>
                                    <a href="post-ad.html">➕ Post New Ad</a>
                                    <hr />
                                    <a href="javascript:void(0)" onclick="Auth.logout()" class="text-danger">🚪 Logout</a>
                                </div>
                            </div>
                        ` : `
                            <a href="register.html?mode=login" class="nav-login-link">Login</a>
                            <a href="register.html" class="btn btn-outline">Register</a>
                        `}

                        <!-- Sell Button (OLX signature styled) -->
                        <a href="post-ad.html" class="btn-sell" title="Post Free Ad">
                            <span class="sell-plus">+</span> SELL
                        </a>
                    </div>
                </div>
            </nav>

            <!-- Quick Categories Secondary Bar -->
            <div class="quick-category-bar">
                <div class="container quick-cat-inner">
                    <span class="quick-cat-title">ALL CATEGORIES:</span>
                    <a href="category.html?category=Mobiles" class="quick-cat-item">📱 Mobiles</a>
                    <a href="category.html?category=Vehicles" class="quick-cat-item">🚗 Vehicles</a>
                    <a href="category.html?category=Electronics" class="quick-cat-item">💻 Electronics</a>
                    <a href="category.html?category=Real Estate" class="quick-cat-item">🏠 Real Estate</a>
                    <a href="category.html?category=Home Services" class="quick-cat-item">🛠️ Home Services</a>
                    <a href="category.html?category=Professional Services" class="quick-cat-item">💼 Professional Services</a>
                    <a href="explore.html" class="quick-cat-item explore-all-link">🔎 Filter City + Category</a>
                </div>
            </div>
        `;
    },

    getFooterHtml() {
        return `
            <div class="footer-top">
                <div class="container footer-grid">
                    <div class="footer-col">
                        <h4>Popular Categories</h4>
                        <ul>
                            <li><a href="category.html?category=Mobiles">Mobiles & Tablets</a></li>
                            <li><a href="category.html?category=Vehicles">Cars & Bikes</a></li>
                            <li><a href="category.html?category=Electronics">Laptops & Appliances</a></li>
                            <li><a href="category.html?category=Home Services">Home & Repair Services</a></li>
                            <li><a href="category.html?category=Real Estate">Apartments & Houses</a></li>
                        </ul>
                    </div>

                    <div class="footer-col">
                        <h4>Popular Cities</h4>
                        <ul>
                            <li><a href="city.html?city=Mumbai">Mumbai Listings</a></li>
                            <li><a href="city.html?city=Delhi">Delhi NCR Listings</a></li>
                            <li><a href="city.html?city=Bengaluru">Bengaluru Listings</a></li>
                            <li><a href="city.html?city=Hyderabad">Hyderabad Listings</a></li>
                            <li><a href="city.html?city=Pune">Pune Listings</a></li>
                        </ul>
                    </div>

                    <div class="footer-col">
                        <h4>Assignment Assessment Pages</h4>
                        <ul>
                            <li><a href="register.html">1. User Registration</a></li>
                            <li><a href="post-ad.html">2. Add Product/Service (10 Fields)</a></li>
                            <li><a href="category.html">4.a Category Page</a></li>
                            <li><a href="city.html">4.b City Wise Listing</a></li>
                            <li><a href="explore.html">4.c City + Category Wise</a></li>
                            <li><a href="listing.html?id=ad-101">4.d Sample Listing Page</a></li>
                        </ul>
                    </div>

                    <div class="footer-col">
                        <h4>OLX Marketplace Demo</h4>
                        <p class="footer-desc">
                            Built as a clean, responsive vanilla HTML5, CSS3, and modern JavaScript web application. 
                            Features complete offline persistence with LocalStorage, cascading location and category filters, and user authentication.
                        </p>
                        <div class="footer-badges">
                            <span class="tech-badge">Pure HTML5</span>
                            <span class="tech-badge">Vanilla CSS3</span>
                            <span class="tech-badge">Modern ES6+</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="container footer-bottom-inner">
                    <p>© 2026 OLX Marketplace Assessment Project. All rights reserved.</p>
                    <p>Designed for Web Developer Internship Evaluation.</p>
                </div>
            </div>
        `;
    },

    bindHeaderEvents() {
        // Toggle user menu dropdown
        const userBtn = document.getElementById("user-menu-btn");
        const userDropdown = document.getElementById("user-dropdown-menu");
        if (userBtn && userDropdown) {
            userBtn.addEventListener("click", (e) => {
                e.stopPropagation();
                userDropdown.classList.toggle("show");
            });

            document.addEventListener("click", () => {
                userDropdown.classList.remove("show");
            });
        }

        // Search submit handler
        const searchForm = document.getElementById("header-search-form");
        const searchInput = document.getElementById("header-search-input");
        const citySelect = document.getElementById("header-city-select");

        // Set initial city in header dropdown from query params if present
        const urlParams = new URLSearchParams(window.location.search);
        const cityParam = urlParams.get("city");
        const queryParam = urlParams.get("q") || urlParams.get("query");

        if (citySelect && cityParam) {
            citySelect.value = cityParam;
        }
        if (searchInput && queryParam) {
            searchInput.value = queryParam;
        }

        if (searchForm) {
            searchForm.addEventListener("submit", (e) => {
                e.preventDefault();
                const q = searchInput.value.trim();
                const city = citySelect ? citySelect.value : "";
                
                let targetUrl = `explore.html?`;
                const params = [];
                if (q) params.push(`query=${encodeURIComponent(q)}`);
                if (city) params.push(`city=${encodeURIComponent(city)}`);
                
                window.location.href = `explore.html?${params.join("&")}`;
            });
        }

        if (citySelect) {
            citySelect.addEventListener("change", () => {
                const selectedCity = citySelect.value;
                if (selectedCity) {
                    window.location.href = `city.html?city=${encodeURIComponent(selectedCity)}`;
                } else {
                    window.location.href = `city.html`;
                }
            });
        }
    }
};

// Auto-run on DOMContentLoaded
document.addEventListener("DOMContentLoaded", () => {
    Navbar.render();
});
