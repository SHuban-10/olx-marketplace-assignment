/**
 * OLX Marketplace - User Authentication Module
 * Handles User Registration, Login, Session in LocalStorage (Requirement 1)
 */

const Auth = {
    USERS_KEY: "olx_users_db_v1",
    SESSION_KEY: "olx_current_user_v1",

    /**
     * Initializes default demo user if not already present
     */
    init() {
        const existingUsers = localStorage.getItem(this.USERS_KEY);
        if (!existingUsers) {
            const defaultUsers = [
                {
                    id: "user-demo-1",
                    name: "Shuban Sharma",
                    email: "demo@olx.com",
                    password: "password123",
                    phone: "+91 98765 43210",
                    city: "Mumbai",
                    createdAt: new Date().toISOString()
                }
            ];
            localStorage.setItem(this.USERS_KEY, JSON.stringify(defaultUsers));
        }
    },

    /**
     * Get all registered users
     */
    getAllUsers() {
        this.init();
        try {
            return JSON.parse(localStorage.getItem(this.USERS_KEY)) || [];
        } catch (e) {
            console.error("Error reading users", e);
            return [];
        }
    },

    /**
     * Requirement 1: Register new user
     */
    register(userData) {
        this.init();
        const users = this.getAllUsers();
        const email = userData.email.trim().toLowerCase();

        // Check if user already exists
        const exists = users.some(u => u.email.toLowerCase() === email);
        if (exists) {
            return { success: false, message: "An account with this email already exists. Please log in." };
        }

        if (!userData.password || userData.password.length < 6) {
            return { success: false, message: "Password must be at least 6 characters long." };
        }

        const newUser = {
            id: "user-" + Date.now(),
            name: userData.name.trim(),
            email: email,
            password: userData.password, // In plain frontend demo, store in state
            phone: (userData.phone || "").trim(),
            city: (userData.city || "Mumbai").trim(),
            createdAt: new Date().toISOString()
        };

        users.push(newUser);
        localStorage.setItem(this.USERS_KEY, JSON.stringify(users));

        // Automatically log in newly registered user
        this.setCurrentUser(newUser);

        return { success: true, user: newUser };
    },

    /**
     * Login user
     */
    login(email, password) {
        this.init();
        const users = this.getAllUsers();
        const cleanEmail = (email || "").trim().toLowerCase();
        
        const matched = users.find(u => u.email.toLowerCase() === cleanEmail && u.password === password);
        if (!matched) {
            return { success: false, message: "Invalid email or password. Please try again." };
        }

        this.setCurrentUser(matched);
        return { success: true, user: matched };
    },

    /**
     * Save active user session
     */
    setCurrentUser(user) {
        const safeUser = { ...user };
        delete safeUser.password;
        localStorage.setItem(this.SESSION_KEY, JSON.stringify(safeUser));
    },

    /**
     * Get currently logged-in user
     */
    getCurrentUser() {
        try {
            const data = localStorage.getItem(this.SESSION_KEY);
            return data ? JSON.parse(data) : null;
        } catch (e) {
            return null;
        }
    },

    /**
     * Check if user is logged in
     */
    isLoggedIn() {
        return this.getCurrentUser() !== null;
    },

    /**
     * Log out current user
     */
    logout() {
        localStorage.removeItem(this.SESSION_KEY);
        window.location.reload();
    },

    /**
     * Auth guard for protected pages (e.g. Post Ad)
     */
    requireAuth(redirectUrl = "post-ad.html") {
        if (!this.isLoggedIn()) {
            sessionStorage.setItem("olx_redirect_after_login", redirectUrl);
            window.location.href = `register.html?mode=login&notice=auth_required`;
            return false;
        }
        return true;
    }
};

Auth.init();
